'use strict';

/* App Module */
var messagingApp = angular.module('messagingApp',
    ['ngRoute',
        'messagingControllers',
        'messagingServices',
        'ngJSONPath']);

messagingApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/auth', {
            templateUrl: 'partials/authentication.html',
            controller: 'AuthenticationCtrl'
        })
        .when('/message/:userId', {
            templateUrl: 'partials/message.html',
            controller: 'MessageCtrl'
        })
        .when('/messageView', {
            templateUrl: 'partials/message.html',
            controller: 'AuthenticationCtrl'
        })
        .otherwise({
            redirectTo: '/auth'
        });
}]);

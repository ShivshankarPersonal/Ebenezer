'use strict';

/* Controllers */

var messagingControllers = angular.module('messagingControllers', []);

messagingControllers.controller('AuthenticationCtrl', ['$scope', '$rootScope', '$http', 'proxyURLBuilder', 'httpProxy', 'jsonPath', '$location',
    function ($scope, $rootScope, $http, proxyURLBuilder, httpProxy, jsonPath, $location) {

        /** Map containing auth key and expire time stamp etc.. info per host, host is used as key **/
        $rootScope.hostAuthKeys = [];

        /** URL returned by for doing authentication **/
        var authURL;

        /** For which host the auth url was returned **/
        var authHost;

        //For Testing - Delete after testing
        $scope.user = "esathe001c@cable.comcast.com";
        $scope.pass = "Welc2016";
        $scope.messageto = "sip:ebenezer_sathe@comcast.com";
        $scope.message = "Hi there this is working now....";

        var userName;
        var password;

        var userLink;
        var applicationLink;
        var applicationObject;
        $rootScope.applicationRootContext; // most of the response will come relative to application root Context
        $rootScope.startMessagingLink;
        $rootScope.presenceSubscriptions;

        //TODO : in future this can not be global - need to be tracked by sending and receiving...
        $rootScope.eventsLink;

        $scope.authStatus = 'pending';
        $scope.eventList = 'will be listed below \n....';
        $scope.pathResult = 'None';


        $scope.testJsonPath = function (thePath) {
            var json = {
                "_links": {
                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/events?ack=2"},
                    "next": {"href": "/ucwa/oauth/v1/applications/10443775565/events?ack=4"}
                },
                "sender": [{
                    "rel": "communication",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication",
                    "events": [{
                        "link": {
                            "rel": "conversation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"
                        },
                        "_embedded": {
                            "conversation": {
                                "state": "Connected",
                                "threadId": "AdGlm8oJB0ui2K1JnkqjCJ3mJrnvgA==",
                                "subject": "Task Sample",
                                "activeModalities": [],
                                "importance": "Normal",
                                "recording": false,
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"},
                                    "applicationSharing": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/applicationSharing"},
                                    "audioVideo": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/audioVideo"},
                                    "dataCollaboration": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/dataCollaboration"},
                                    "messaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"},
                                    "phoneAudio": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/phoneAudio"},
                                    "localParticipant": {
                                        "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                                        "title": "Kansara, Munjal (Contractor)"
                                    }
                                },
                                "rel": "conversation"
                            }
                        },
                        "type": "updated"
                    }]
                }, {
                    "rel": "conversation",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b",
                    "events": [{
                        "link": {
                            "rel": "participant",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                            "title": ""
                        }, "type": "added"
                    }, {
                        "link": {
                            "rel": "participantMessaging",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com/messaging"
                        },
                        "in": {
                            "rel": "participant",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                            "title": ""
                        },
                        "type": "added"
                    }, {
                        "link": {
                            "rel": "messaging",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"
                        },
                        "_embedded": {
                            "messaging": {
                                "state": "Connected",
                                "negotiatedMessageFormats": ["Plain"],
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"},
                                    "stopMessaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/terminate"},
                                    "sendMessage": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/messages"},
                                    "setIsTyping": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/typing"},
                                    "typingParticipants": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/typingParticipants"}
                                },
                                "rel": "messaging"
                            }
                        },
                        "type": "updated"
                    }]
                }, {
                    "rel": "communication",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication",
                    "events": [{
                        "link": {
                            "rel": "messagingInvitation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/messagingInvitations/b5b0c7104edd4ea1b72866503d115c53"
                        },
                        "status": "Success",
                        "_embedded": {
                            "messagingInvitation": {
                                "direction": "Outgoing",
                                "importance": "Normal",
                                "threadId": "AdGlm8oJB0ui2K1JnkqjCJ3mJrnvgA==",
                                "state": "Connected",
                                "operationId": "5028e824-2268-4b14-9e59-1abad65ff393",
                                "subject": "Task Sample",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/messagingInvitations/b5b0c7104edd4ea1b72866503d115c53"},
                                    "from": {
                                        "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                                        "title": "Kansara, Munjal (Contractor)"
                                    },
                                    "to": {"href": "/ucwa/oauth/v1/applications/10443775565/people/munjal_kansara@cable.comcast.com"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"},
                                    "messaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"}
                                },
                                "_embedded": {
                                    "acceptedByParticipant": [{
                                        "sourceNetwork": "SameEnterprise",
                                        "anonymous": false,
                                        "name": "",
                                        "uri": "sip:Munjal_Kansara@cable.comcast.com",
                                        "_links": {
                                            "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com"},
                                            "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"},
                                            "me": {"href": "/ucwa/oauth/v1/applications/10443775565/me"},
                                            "participantMessaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com/messaging"}
                                        },
                                        "rel": "participant"
                                    }]
                                },
                                "rel": "messagingInvitation"
                            }
                        },
                        "type": "completed"
                    }]
                }, {
                    "rel": "conversation",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b",
                    "events": [{
                        "link": {
                            "rel": "message",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/messages/2"
                        },
                        "status": "Success",
                        "_embedded": {
                            "message": {
                                "direction": "Outgoing",
                                "timeStamp": "/Date(1462321672170)/",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging/messages/2"},
                                    "messaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"}
                                },
                                "rel": "message"
                            }
                        },
                        "type": "completed"
                    }, {
                        "link": {
                            "rel": "messaging",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"
                        },
                        "_embedded": {
                            "messaging": {
                                "state": "Disconnected",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/messaging"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"}
                                },
                                "rel": "messaging"
                            }
                        },
                        "reason": {
                            "code": "Informational",
                            "subcode": "Ended",
                            "message": "The conversation has ended."
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "participant",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                            "title": ""
                        }, "type": "deleted"
                    }, {
                        "link": {
                            "rel": "localParticipant",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b/participants/munjal_kansara@cable.comcast.com",
                            "title": "Kansara, Munjal (Contractor)"
                        }, "type": "deleted"
                    }]
                }, {
                    "rel": "communication",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication",
                    "events": [{
                        "link": {
                            "rel": "conversation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"
                        },
                        "_embedded": {
                            "conversation": {
                                "state": "Disconnected",
                                "_links": {"self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"}},
                                "rel": "conversation"
                            }
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "conversation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/d60e9473-cd56-4edd-88b1-fbadd916172b"
                        }, "type": "deleted"
                    }, {
                        "link": {
                            "rel": "messagingInvitation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/messagingInvitations/1f3f216a9b814b5dafb837b90824b48b"
                        },
                        "_embedded": {
                            "messagingInvitation": {
                                "direction": "Outgoing",
                                "importance": "Normal",
                                "threadId": "AdGlm95K+JNSETWGwUWd4bGnWXH0hg==",
                                "state": "Connecting",
                                "operationId": "5028e824-2268-4b14-9e59-1abad65ff393",
                                "subject": "Task Sample",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/messagingInvitations/1f3f216a9b814b5dafb837b90824b48b"},
                                    "from": {
                                        "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/participants/munjal_kansara@cable.comcast.com",
                                        "title": "Kansara, Munjal (Contractor)"
                                    },
                                    "to": {"href": "/ucwa/oauth/v1/applications/10443775565/people/munjal_kansara@cable.comcast.com"},
                                    "cancel": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging/terminate"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"},
                                    "messaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging"}
                                },
                                "rel": "messagingInvitation"
                            }
                        },
                        "type": "started"
                    }, {
                        "link": {
                            "rel": "conversation",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"
                        },
                        "_embedded": {
                            "conversation": {
                                "state": "Connecting",
                                "threadId": "AdGlm95K+JNSETWGwUWd4bGnWXH0hg==",
                                "subject": "Task Sample",
                                "activeModalities": [],
                                "importance": "Normal",
                                "recording": false,
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"},
                                    "applicationSharing": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/applicationSharing"},
                                    "audioVideo": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/audioVideo"},
                                    "dataCollaboration": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/dataCollaboration"},
                                    "messaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging"},
                                    "phoneAudio": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/phoneAudio"}
                                },
                                "rel": "conversation"
                            }
                        },
                        "type": "added"
                    }]
                }, {
                    "rel": "conversation",
                    "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad",
                    "events": [{
                        "link": {
                            "rel": "localParticipant",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/participants/munjal_kansara@cable.comcast.com",
                            "title": "Kansara, Munjal (Contractor)"
                        },
                        "_embedded": {
                            "localParticipant": {
                                "sourceNetwork": "SameEnterprise",
                                "anonymous": false,
                                "name": "Kansara, Munjal (Contractor)",
                                "uri": "sip:Munjal_Kansara@cable.comcast.com",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/participants/munjal_kansara@cable.comcast.com"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"},
                                    "me": {"href": "/ucwa/oauth/v1/applications/10443775565/me"}
                                },
                                "rel": "participant"
                            }
                        },
                        "type": "added"
                    }, {
                        "link": {
                            "rel": "messaging",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging"
                        },
                        "_embedded": {
                            "messaging": {
                                "state": "Connecting",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"},
                                    "stopMessaging": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/messaging/terminate"}
                                },
                                "rel": "messaging"
                            }
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "audioVideo",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/audioVideo"
                        },
                        "_embedded": {
                            "audioVideo": {
                                "state": "Disconnected",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/audioVideo"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"}
                                },
                                "rel": "audioVideo"
                            }
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "phoneAudio",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/phoneAudio"
                        },
                        "_embedded": {
                            "phoneAudio": {
                                "state": "Disconnected",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/phoneAudio"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"}
                                },
                                "rel": "phoneAudio"
                            }
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "applicationSharing",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/applicationSharing"
                        },
                        "_embedded": {
                            "applicationSharing": {
                                "state": "Disconnected",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/applicationSharing"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"}
                                },
                                "rel": "applicationSharing"
                            }
                        },
                        "type": "updated"
                    }, {
                        "link": {
                            "rel": "dataCollaboration",
                            "href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/dataCollaboration"
                        },
                        "_embedded": {
                            "dataCollaboration": {
                                "state": "Disconnected",
                                "_links": {
                                    "self": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad/dataCollaboration"},
                                    "conversation": {"href": "/ucwa/oauth/v1/applications/10443775565/communication/conversations/7e4438a7-a1fd-4a4a-8184-68f9db1620ad"}
                                },
                                "rel": "dataCollaboration"
                            }
                        },
                        "type": "updated"
                    }]
                }]
            };
            $scope.pathResult = jsonPath(json, thePath);

        }

        $scope.sendMessage = function (messageto, message) {
            console.log('sendMessage...');
            getAuthHeader($rootScope.startMessagingLink)
                .then(function (authKey) {
                    console.log('sending messagingInvitations...');

                    //POST to startMessagingLink
                    var reqObj = {
                        method: 'POST',
                        url: $rootScope.startMessagingLink,
                        headers: {
                            'accept': 'application/json',
                            'Authorization': authKey,
                            'Content-Type': 'application/json'
                        },
                        data: {
                            "importance": "Normal",
                            "sessionContext": "344c0ef6-0570-4467-bb7e-49fcbea8e944",
                            "subject": "Task Sample",
                            "telemetryId": null,
                            "to": messageto,
                            "operationId": "5028e824-2268-4b14-9e59-1abad65ff393"
                        }
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('messagingInvitations response...' + JSON.stringify(response));

                    var invitationLocation = response.headers("Location");
                    console.log('messagingInvitations created...' + invitationLocation);

                    //Success so proceed forward and track down events...
                    return processEventsUntilConversationStarts(invitationLocation);
                })
                .then(function (conversationLink) {
                    return getAuthHeader(conversationLink)
                        .then(function (authKey) {
                            var reqObj = {
                                method: 'GET',
                                url: conversationLink,
                                headers: {'accept': 'application/json', 'Authorization': authKey}
                            };
                            return httpProxy(reqObj);
                        })


                })
                .then(function (response) {
                    try {
                        console.log('conversationLink response...' + JSON.stringify(response));
                        //var messaingLink = response.data._links.messaging.href;
                        if (response.data && response.data._links && response.data._links.messaging.href) {
                            var messaingLink = response.data._links.messaging.href;
                        }
                        //get the messaging url
                        var sendMsgToLink = $rootScope.applicationRootContext + messaingLink + "/messages?OperationContext=munjaltest" + new Date().getTime();
                        console.log('sendMsgToLink Link...' + sendMsgToLink + " data : " + message);

                        //POST the message
                        return getAuthHeader(sendMsgToLink)
                            .then(function (authKey) {
                                var reqObj = {
                                    method: 'POST',
                                    url: sendMsgToLink,
                                    headers: {
                                        'accept': 'application/json',
                                        'Authorization': authKey,
                                        'Content-Type': 'text/plain'
                                    },
                                    data: message
                                };
                                return httpProxy(reqObj);
                            })
                    } catch (e) {
                        console.log(e);
                    }
                })
                .then(function (response) {
                    console.log('sent message...' + JSON.stringify(response));

                    var loc = response.headers("Location");
                    $scope.eventList = $scope.eventList + "\n message sent successfully - " + loc;
                    $scope.$apply();

                    //now process all pending events...
                    return processAllOpenEvents();
                })
//		.then(function(conversationLink){
//			//Now stopMessaging
//			if(conversationLink){
//				return getAuthHeader(conversationLink)
//				.then(function(authKey){
//					var reqObj = {method: 'GET',
//							url: conversationLink,
//							headers: {'accept': 'application/json', 'Authorization' : authKey}};
//			        return httpProxy(reqObj);
//				})
//				.then(function(response){
//					console.log('stopMessaging  response...' + JSON.stringify(response));
//
//					//get the messaging url
//					var stopMessagingLink = applicationRootContext + response.data._links.messaging.href + "/terminate?OperationContext=munjaltest" + new Date().getTime() ;
//					console.log('terminate Link...' + terminate);
//
//					//POST the message
//					return getAuthHeader(stopMessagingLink)
//					.then(function(authKey){
//						var reqObj = {method: 'POST',
//								url: sendMsgToLink,
//								headers: {'accept': 'application/json', 'Authorization' : authKey}
//							};
//				        return httpProxy(reqObj);
//					})
//				})
//				.then(function(response){
//					console.log('stopMessaging  done...');
//					$scope.eventList = $scope.eventList + "\n stopMessaging done..." ;
//					$scope.$apply();
//				});
//			}
//			else{
//				$scope.eventList = $scope.eventList + "\n done without termination" ;
//				$scope.$apply();
//			}
//		})
            ;
        }

        function processAllOpenEvents() {
            var stopChat = false;
            $scope.eventList = $scope.eventList + "\n Processing : " + $scope.eventsLink;
            return getAuthHeader($scope.eventsLink)
                .then(function (authKey) {
                    var reqObj = {
                        method: 'GET',
                        url: $scope.eventsLink,
                        headers: {'accept': 'application/json', 'Authorization': authKey}
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('event : ' + JSON.stringify(response.data));

                    //TODO : in future we should be using JSON Path to reduce complexity...
                    //select Node with sender->events[link[messagingInvitation & href=Location]->_embedded->messagingInvitation->state=Connected]
                    //get value of messagingInvitation->_links->conversation
                    var nextEventPath = "$._links.next.href";
                    var eventsLinkResult = jsonPath(response.data, nextEventPath);

                    console.log('got eventsLinkResult =' + eventsLinkResult);

                    //TODO: More defense & validation should be done...
                    if (eventsLinkResult) {
                        //proceed to open chat
                        $scope.eventsLink = $rootScope.applicationRootContext + eventsLinkResult;

                        var messagePath = "$..plainMessage.href";
                        var messageData = jsonPath(response.data, messagePath);
                        if (messageData) {
                            if (JSON.stringify(messageData).indexOf("done") > -1) {
                                stopChat = true;
                            }
                            $scope.eventList = $scope.eventList + "\n Message : " + messageData + " -- Stopping:" + stopChat;
                            $scope.$apply();
                        }
                        console.log('opening eventsLink =' + $scope.eventsLink);
                        if (!stopChat) {
                            return processAllOpenEvents();
                        }
                        else {
                            console.log('Stopping bbye ');
//					var conversationPath = "$.sender[?(@.rel=='communication')].events[?(@.link.rel=='messagingInvitation' && @._embedded.messagingInvitation.state=='Connected')]._embedded.messagingInvitation._links.conversation.href";
//					var conversationLink = jsonPath(response.data, conversationPath);
//
//					console.log('got conversationLink =' + conversationLink);
//
//					//TODO: More defense & validation should be done...
//					if(conversationLink){
//						//proceed to open chat
//						conversationLink = applicationRootContext + conversationLink;
//
//						console.log('closing conversation =' + conversationLink);
//						return conversationLink;
//					}
//					else{
                            return false;
//					}
                        }
                    }
                })
                ;
        }

        function processEventsUntilConversationStarts(invitationLocation) {
            $scope.eventList = $scope.eventList + "\n Processing : " + $scope.eventsLink;
            return getAuthHeader($scope.eventsLink)
                .then(function (authKey) {
                    var reqObj = {
                        method: 'GET',
                        url: $scope.eventsLink,
                        headers: {'accept': 'application/json', 'Authorization': authKey}
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    try {
                        console.log('event : ' + JSON.stringify(response.data));

                        //TODO : in future we should be using JSON Path to reduce complexity...
                        //select Node with sender->events[link[messagingInvitation & href=Location]->_embedded->messagingInvitation->state=Connected]
                        //get value of messagingInvitation->_links->conversation
                        var conversationPath = "$.sender[?(@.rel=='communication')].events[?(@.link.rel=='messagingInvitation' && @.link.href=='" + invitationLocation + "' && @._embedded.messagingInvitation.state=='Connected')]._embedded.messagingInvitation._links.conversation.href";
                        var conversationLink = jsonPath(response.data, conversationPath);

                        console.log('got conversationLink =' + conversationLink);

                        //TODO: More defense & validation should be done...
                        if (conversationLink) {
                            //proceed to open chat
                            conversationLink = $rootScope.applicationRootContext + conversationLink;

                            console.log('opening conversation =' + conversationLink);
                            return conversationLink;
                        }
                        else {
                            //try next event...
                            $scope.eventsLink = $rootScope.applicationRootContext + response.data._links.next.href;

                            console.log('trying next eventsLink =' + $scope.eventsLink);
                            return processEventsUntilConversationStarts(invitationLocation);
                        }
                    } catch (e) {
                        console.log(e);
                    }
                })
                ;
        }

        $scope.authenticate = function (user, pass) {
            $scope.authStatus = 'Initiated';
            userName = user;
            password = pass;

            //Get user link
            httpProxy.get('https://lyncdiscover.cable.comcast.com').success(function (responseData) {
                console.log("Response : " + JSON.stringify(responseData));
                userLink = responseData._links.user.href;
                console.log("User Link: " + userLink);

                var reqObj = {method: 'GET', url: userLink, headers: {'accept': 'application/json'}};
                httpProxy(reqObj)
                    .then(function (responseData) {
                        console.log("got success where not expected --- Data : " + JSON.stringify(responseData));
                    })
                    .catch(function (errorData) {
                        //Should give 401
                        if (errorData.status == 401) {
                            //We are good - let us get necessary information
                            //Get header for authentication location...
                            var authHeader = errorData.headers('WWW-Authenticate');
                            console.log("headers : " + authHeader);

                            //get the URL to authenticate e.g. from response :
                            // Bearer trusted_issuers="00000002-0000-0ff1-ce00-000000000000@cable.comcast.com", client_id="00000004-0000-0ff1-ce00-000000000000", MsRtcOAuth href="https://extlyncpool04.comcast.com/WebTicket/oauthtoken",grant_type="urn:microsoft.rtc:windows,urn:microsoft.rtc:anonmeeting,password"
                            authURL = authHeader.replace(/.*href="([^"]*)".*/i, "$1");
                            authHost = getHost(authURL);
                            console.log("setting authURL=" + authURL + ", authHost = " + authHost);

                            //get host for userObject
                            return getAuthHeader(authURL);
                        }
                        else {
                            //not good
                            console.log("Bad errorData : " + JSON.stringify(errorData));
                        }
                    })
                    .then(function (authKey) {
                        $scope.authStatus = 'Getting application...';
                        console.log("successfully authenticated authKey  : " + authKey);

                        //create the application now
                        return createApplication();
                    });
            });
        }

        /** Create Application **/
        function createApplication() {
            console.log('creating application...');
            getAuthHeader(userLink)
                .then(function (authKey) {

                    //get the info from user URL
                    var reqObj = {
                        method: 'GET',
                        url: userLink,
                        headers: {'accept': 'application/json', 'Authorization': authKey}
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log("got from user link Data : " + JSON.stringify(response));

                    //TODO: become defensive & validate before blank retrieval...
                    applicationLink = response.data._links.applications.href;

                    console.log('setting application link : ' + applicationLink);

                    return getAuthHeader(applicationLink);
                })
                .then(function (authKey) {
                    var reqObj = {
                        method: 'POST',
                        url: applicationLink,
                        headers: {
                            'accept': 'application/json',
                            'Authorization': authKey,
                            'Content-Type': 'application/json'
                        },
                        data: {
                            "UserAgent": "TN-Messaging-Munjal",
                            "EndpointId": "aq1eeeee-976c-4cf3-847d-cdfffa28ccdf",
                            "Culture": "en-US"
                        }
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    applicationObject = response.data;
                    console.log('applicationLink response : ', response);

                    $rootScope.applicationRootContext = removeURIPath(applicationLink);
                    $rootScope.startMessagingLink = $rootScope.applicationRootContext + response.data._embedded.communication._links.startMessaging.href;
                    $rootScope.eventsLink = $rootScope.applicationRootContext + response.data._links.events.href;
                    $rootScope.presenceSubscriptions = $rootScope.applicationRootContext + response.data._embedded.people._links.myGroups.href;
                    console.log('set applicationRootContext = ' + $rootScope.applicationRootContext + ' & startMessagingLink to: ' + $rootScope.startMessagingLink);
                    console.log('presenceSubscriptions:::::' + $rootScope.presenceSubscriptions);
                    //Wow did not know this :) - see http://jimhoskins.com/2012/12/17/angularjs-and-apply.html &
                    // http://nathanleclaire.com/blog/2014/01/31/banging-your-head-against-an-angularjs-issue-try-this/
                    $scope.authStatus = 'authenticated - ready to send message';

                    $scope.$apply();
                    $location.path('/message/' + userName);

                });
        }


        /** Retrieves oAuth key for given host - if not found initiate authentication **/
        function getAuthHeader(forUrl) {
            var forHost = getHost(forUrl);
            console.log('getting authkey for host : ' + forHost + ' -- ' + $rootScope.hostAuthKeys[forHost]);

            if ($rootScope.hostAuthKeys[forHost] == undefined) {
                console.log('initiating authentication for host ' + forHost);
                return authenticate(forHost)
                    .then(
                        function (responseData) {
                            console.log("authenticate Success  : " + JSON.stringify(responseData.data));

                            //TODO : perform basic sanity check that it has needed data else raise error
                            //example here : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/catch

                            //add to hostAuthKeys
                            $rootScope.hostAuthKeys[forHost] = responseData.data;

                            //return the authKey
                            var authHeader =
                                $rootScope.hostAuthKeys[forHost].token_type + ' ' +
                                $rootScope.hostAuthKeys[forHost].access_token;
                            console.log('authHeader = ' + authHeader);

                            return authHeader;
                        },
                        function (errorData) {
                            console.log("someting went wrong  : " + JSON.stringify(errorData));
                            return null;
                        }
                    );
            }
            else {
                //TODO: check if it's still valid else authenticate...
                return new Promise(function (resolve, reject) {
                    var authHeader =
                        $rootScope.hostAuthKeys[forHost].token_type + ' ' +
                        $rootScope.hostAuthKeys[forHost].access_token;
                    console.log('authHeader2 = ' + authHeader);
                    resolve(authHeader);
                });
            }
        }

        /** Perform authentication for given host **/
        function authenticate(forHost) {
            //build the auth url for host
            var hostAuthUrl = authURL.replace(authHost, forHost);
            console.log('will authenticate against URL : ' + hostAuthUrl);
            var reqObj = {
                method: 'POST', url: hostAuthUrl, headers: {
                    'accept': 'application/json',
                    'Content-Type': "application/x-www-form-urlencoded"
                },
                data: 'grant_type=password&username=' + userName + '&password=' + password
            };
            //data: 'urn:microsoft.rtc:windows'};

            return httpProxy(reqObj);
        }

        // Extract host from given URL
        function getHost(theUrl) {
            try { //TODO: validate the domain name must be comcast.com else throw error
                var subHost = theUrl.replace(/https?:\/\/([^\/]*).comcast.com.*$/i, "$1");
                console.log("url : " + theUrl + " - subHost " + subHost);
                return subHost;
            } catch (e) {
                console.log(e);
            }
        }

        // Extract host from given URL
        function removeURIPath(fromUrl) {
            //TODO: validate the domain name must be comcast.com else throw error
            var rootContext = fromUrl.replace(/(https?:\/\/[^\/]*)\/.*$/i, "$1");
            console.log("url : " + fromUrl + " - removeURIPath " + rootContext);
            return rootContext;
        }

    }]);
// Here we click on the send button and get request in passed on MyGroupContacts API and starts the "presence concept"
messagingControllers.controller('MessageCtrl', ['$scope', '$rootScope', '$routeParams', '$http', 'proxyURLBuilder', 'httpProxy', 'jsonPath', '$location',
    function ($scope, $rootScope, $routeParams, $http, proxyURLBuilder, httpProxy, jsonPath, $location) {
        $scope.userId = $routeParams.userId;
        /* Values hardcoded for time being*/
        $scope.onlineUsers = [
            {'userName': 'Ebenezer Sathe', 'emailId': 'sip:ebenezer_sathe@comcast.com'},
            {'userName': 'Munjal Kansara', 'emailId': 'sip:Munjal_Kansara@cable.comcast.com'},
            {'userName': 'Rupesh chetri', 'emailId': 'sip:Rupesh_Chhetri@cable.comcast.com'},
            {'userName': 'Peter Clarke', 'emailId': 'peter@cable.comcast.com'}
        ];

        $scope.showStatus = false; // intialize status to false

        $scope.checkUserOnline = function (userId) {

            console.log('$rootScope.presenceSubscriptions:::', $rootScope.presenceSubscriptions);

            getAuthHeader($rootScope.presenceSubscriptions)
                .then(function (authKey) {
                    console.log('sending messagingInvitations...');
                    console.log(authKey);
                    //POST to startMessagingLink
                    var reqObj = {
                        method: 'GET',
                        url: $rootScope.presenceSubscriptions,
                        headers: {
                            'accept': 'application/json',
                            'Authorization': authKey,
                            'Content-Type': 'application/json'
                        }
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('myGroups response' + JSON.stringify(response));
                    var pinnedGroupURL = $rootScope.applicationRootContext + response.data._embedded.pinnedGroup._links.groupContacts.href;
                    var defaultGroupURL = $rootScope.applicationRootContext + response.data._embedded.defaultGroup._links.groupContacts.href;
                    return getAuthHeader(defaultGroupURL)
                        .then(function (authKey) {
                            var reqObj = {
                                method: 'GET',
                                url: defaultGroupURL,
                                headers: {
                                    'accept': 'application/json',
                                    'Authorization': authKey,
                                    'Content-Type': 'application/json'
                                }
                            };
                            return httpProxy(reqObj);
                        })// Parse the response from a GET request on the myGroups resource to obtain the specified group resource.


                }).then(function (response) {
                console.log('defaultGroupURL:::', response);
                return checkUserPresence(response.data._embedded.contact, userId);

            }).then(function (presenceLink) {
                // GET request on the groupContacts resource from the group
                console.log('presenceResponse ', presenceLink);
                return getAuthHeader(presenceLink)
                    .then(function (authKey) {
                        var reqObj = {
                            method: 'GET',
                            url: presenceLink,
                            headers: {
                                'accept': 'application/json',
                                'Authorization': authKey,
                                'Content-Type': 'application/json'
                            }
                        };
                        return httpProxy(reqObj);
                    })
            }).then(function (response) {
                console.log('lresponse ::::: ', response);
                $scope.userStatus = response.data.availability;
                var nameArr = response.config.url.split('/')[7].split('@')[0].split('_');
                for(var i = 0 ; i < nameArr.length; i++){
                    nameArr[i] = firstToUpperCase(nameArr[i]);
                }
                function firstToUpperCase( str ) {
                    return str.substr(0, 1).toUpperCase() + str.substr(1);
                }
                $scope.userEmailId = nameArr.join(' ');
                $scope.showStatus = true;
                $scope.$digest();

            });


        };
        $scope.userStatus;
        //here we are capturing the userid and contact info if they are similar, then we proceed
        function checkUserPresence(contactList, userId) {
            //angular.forEach(contactList, function (contact) {
            //    console.log("contact uri :::: ", contact.uri);
            //    console.log("contact uri :::: ", userId);
            //    if (contact.uri === userId) {
            //    console.log("contact presence ::: ", contact._links.contactPresence.href);
            //
            //    //contact._links.contactPresence.href.split("/")[7];
            //    //contact._links.contactPresence.href.replace(contact._links.contactPresence.href.split("/")[7], userId);
            //    //$scope.presenceUri = $rootScope.applicationRootContext + contact._links.contactPresence.href.replace(contact._links.contactPresence.href.split("/")[7], userId);
            //    $scope.presenceUri = $rootScope.applicationRootContext + contact._links.contactPresence.href;
            //
            //
            //    return $scope.presenceUri;
            //    }
            //});

            var presenceURI = "";
            for(var i = 0; i < contactList.length; i++){
                if(contactList[i].uri === userId){
                    presenceURI = $rootScope.applicationRootContext + contactList[i]._links.contactPresence.href
                }
            }
            return  presenceURI;

        } // end of the presence status

        $scope.sendMessage = function (messageto, message) {


            console.log('sendMessage...');
            getAuthHeader($rootScope.startMessagingLink)
                .then(function (authKey) {
                    console.log('sending messagingInvitations...');
                    console.log(authKey);
                    //POST to startMessagingLink
                    var reqObj = {
                        method: 'POST',
                        url: $rootScope.startMessagingLink,
                        headers: {
                            'accept': 'application/json',
                            'Authorization': authKey,
                            'Content-Type': 'application/json'
                        },
                        data: {
                            "importance": "Normal",
                            "sessionContext": "344c0ef6-0570-4467-bb7e-49fcbea8e944",
                            "subject": "Task Sample",
                            "telemetryId": null,
                            "to": messageto,
                            "operationId": "5028e824-2268-4b14-9e59-1abad65ff393"
                        }
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('messagingInvitations response...' + JSON.stringify(response));

                    var invitationLocation = response.headers("Location");
                    console.log('messagingInvitations created...' + invitationLocation);

                    //Success so proceed forward and track down events...
                    return processEventsUntilConversationStarts(invitationLocation);
                })
                .then(function (conversationLink) {
                    return getAuthHeader(conversationLink)
                        .then(function (authKey) {
                            var reqObj = {
                                method: 'GET',
                                url: conversationLink,
                                headers: {'accept': 'application/json', 'Authorization': authKey}
                            };
                            return httpProxy(reqObj);
                        });
                    console.log('opening conversationLink...');
                })
                .then(function (response) {
                    console.log('conversationLink response...' + JSON.stringify(response));

                    //get the messaging url
                    var sendMsgToLink = $rootScope.applicationRootContext + response.data._links.messaging.href + "/messages?OperationContext=munjaltest" + new Date().getTime();
                    console.log('sendMsgToLink Link...' + sendMsgToLink + " data : " + message);

                    //POST the message
                    return getAuthHeader(sendMsgToLink)
                        .then(function (authKey) {
                            var reqObj = {
                                method: 'POST',
                                url: sendMsgToLink,
                                headers: {
                                    'accept': 'application/json',
                                    'Authorization': authKey,
                                    'Content-Type': 'text/plain'
                                },
                                data: message
                            };
                            return httpProxy(reqObj);
                        })
                })
                .then(function (response) {
                    console.log('sent message...' + JSON.stringify(response));

                    var loc = response.headers("Location");
                    $scope.eventList = $scope.eventList + "\n message sent successfully - " + loc;
                    $scope.$apply();

                    //now process all pending events...
                    return processAllOpenEvents();
                })
//		.then(function(conversationLink){
//			//Now stopMessaging
//			if(conversationLink){
//				return getAuthHeader(conversationLink)
//				.then(function(authKey){
//					var reqObj = {method: 'GET',
//							url: conversationLink,
//							headers: {'accept': 'application/json', 'Authorization' : authKey}};
//			        return httpProxy(reqObj);
//				})
//				.then(function(response){
//					console.log('stopMessaging  response...' + JSON.stringify(response));
//
//					//get the messaging url
//					var stopMessagingLink = applicationRootContext + response.data._links.messaging.href + "/terminate?OperationContext=munjaltest" + new Date().getTime() ;
//					console.log('terminate Link...' + terminate);
//
//					//POST the message
//					return getAuthHeader(stopMessagingLink)
//					.then(function(authKey){
//						var reqObj = {method: 'POST',
//								url: sendMsgToLink,
//								headers: {'accept': 'application/json', 'Authorization' : authKey}
//							};
//				        return httpProxy(reqObj);
//					})
//				})
//				.then(function(response){
//					console.log('stopMessaging  done...');
//					$scope.eventList = $scope.eventList + "\n stopMessaging done..." ;
//					$scope.$apply();
//				});
//			}
//			else{
//				$scope.eventList = $scope.eventList + "\n done without termination" ;
//				$scope.$apply();
//			}
//		})
            ;
        }

        function processAllOpenEvents() {
            var stopChat = false;
            $scope.eventList = $scope.eventList + "\n Processing : " + $rootScope.eventsLink;
            return getAuthHeader($rootScope.eventsLink)
                .then(function (authKey) {
                    var reqObj = {
                        method: 'GET',
                        url: $rootScope.eventsLink,
                        headers: {'accept': 'application/json', 'Authorization': authKey}
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('event : ' + JSON.stringify(response.data));

                    //TODO : in future we should be using JSON Path to reduce complexity...
                    //select Node with sender->events[link[messagingInvitation & href=Location]->_embedded->messagingInvitation->state=Connected]
                    //get value of messagingInvitation->_links->conversation
                    var nextEventPath = "$._links.next.href";
                    var eventsLinkResult = jsonPath(response.data, nextEventPath);

                    console.log('got eventsLinkResult =' + eventsLinkResult);

                    //TODO: More defense & validation should be done...
                    if (eventsLinkResult) {
                        //proceed to open chat
                        $rootScope.eventsLink = $rootScope.applicationRootContext + eventsLinkResult;

                        var messagePath = "$..plainMessage.href";
                        var messageData = jsonPath(response.data, messagePath);
                        if (messageData) {
                            if (JSON.stringify(messageData).indexOf("done") > -1) {
                                stopChat = true;
                            }
                            $scope.eventList = $scope.eventList + "\n Message : " + messageData + " -- Stopping:" + stopChat;
                            $scope.$apply();
                        }
                        console.log('opening eventsLink =' + $rootScope.eventsLink);
                        if (!stopChat) {
                            return processAllOpenEvents();
                        }
                        else {
                            console.log('Stopping bbye ');
//					var conversationPath = "$.sender[?(@.rel=='communication')].events[?(@.link.rel=='messagingInvitation' && @._embedded.messagingInvitation.state=='Connected')]._embedded.messagingInvitation._links.conversation.href";
//					var conversationLink = jsonPath(response.data, conversationPath);
//
//					console.log('got conversationLink =' + conversationLink);
//
//					//TODO: More defense & validation should be done...
//					if(conversationLink){
//						//proceed to open chat
//						conversationLink = applicationRootContext + conversationLink;
//
//						console.log('closing conversation =' + conversationLink);
//						return conversationLink;
//					}
//					else{
                            return false;
//					}
                        }
                    }
                })
                ;
        }

        function processEventsUntilConversationStarts(invitationLocation) {
            $scope.eventList = $scope.eventList + "\n Processing : " + $rootScope.eventsLink;
            return getAuthHeader($rootScope.eventsLink)
                .then(function (authKey) {
                    var reqObj = {
                        method: 'GET',
                        url: $rootScope.eventsLink,
                        headers: {'accept': 'application/json', 'Authorization': authKey}
                    };
                    return httpProxy(reqObj);
                })
                .then(function (response) {
                    console.log('event : ' + JSON.stringify(response.data));

                    //TODO : in future we should be using JSON Path to reduce complexity...
                    //select Node with sender->events[link[messagingInvitation & href=Location]->_embedded->messagingInvitation->state=Connected]
                    //get value of messagingInvitation->_links->conversation
                    var conversationPath = "$.sender[?(@.rel=='communication')].events[?(@.link.rel=='messagingInvitation' && @.link.href=='" + invitationLocation + "' && @._embedded.messagingInvitation.state=='Connected')]._embedded.messagingInvitation._links.conversation.href";
                    var conversationLink = jsonPath(response.data, conversationPath);

                    console.log('got conversationLink =' + conversationLink);

                    //TODO: More defense & validation should be done...
                    if (conversationLink) {
                        //proceed to open chat
                        conversationLink = $rootScope.applicationRootContext + conversationLink;

                        console.log('opening conversation =' + conversationLink);
                        return conversationLink;
                    }
                    else {
                        //try next event...
                        $rootScope.eventsLink = $rootScope.applicationRootContext + response.data._links.next.href;

                        console.log('trying next eventsLink =' + $rootScope.eventsLink);
                        return processEventsUntilConversationStarts(invitationLocation);
                    }
                })
                ;
        }

        /** Retrieves oAuth key for given host - if not found initiate authentication **/
        function getAuthHeader(forUrl) {
            var forHost = getHost(forUrl);
            console.log('getting authkey for host : ' + forHost + ' -- ' + $rootScope.hostAuthKeys[forHost]);

            if ($rootScope.hostAuthKeys[forHost] == undefined) {
                console.log('initiating authentication for host ' + forHost);
                return authenticate(forHost)
                    .then(
                        function (responseData) {
                            console.log("authenticate Success  : " + JSON.stringify(responseData.data));

                            //TODO : perform basic sanity check that it has needed data else raise error
                            //example here : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/catch

                            //add to hostAuthKeys
                            $rootScope.hostAuthKeys[forHost] = responseData.data;

                            //return the authKey
                            var authHeader =
                                $rootScope.hostAuthKeys[forHost].token_type + ' ' +
                                $rootScope.hostAuthKeys[forHost].access_token;
                            console.log('authHeader = ' + authHeader);

                            return authHeader;
                        },
                        function (errorData) {
                            console.log("someting went wrong  : " + JSON.stringify(errorData));
                            return null;
                        }
                    );
            }
            else {
                //TODO: check if it's still valid else authenticate...
                return new Promise(function (resolve, reject) {
                    var authHeader =
                        $rootScope.hostAuthKeys[forHost].token_type + ' ' +
                        $rootScope.hostAuthKeys[forHost].access_token;
                    console.log('authHeader2 = ' + authHeader);
                    resolve(authHeader);
                });
            }
        }

        /** Perform authentication for given host **/
        function authenticate(forHost) {
            //build the auth url for host
            var hostAuthUrl = authURL.replace(authHost, forHost);
            console.log('will authenticate against URL : ' + hostAuthUrl);
            var reqObj = {
                method: 'POST', url: hostAuthUrl, headers: {
                    'accept': 'application/json',
                    'Content-Type': "application/x-www-form-urlencoded"
                },
                data: 'grant_type=password&username=' + userName + '&password=' + password
            };
            //data: 'urn:microsoft.rtc:windows'};

            return httpProxy(reqObj);
        }

        // Extract host from given URL
        function getHost(theUrl) {
            //TODO: validate the domain name must be comcast.com else throw error
            var subHost = theUrl.replace(/https?:\/\/([^\/]*).comcast.com.*$/i, "$1");
            console.log("url : " + theUrl + " - subHost " + subHost);
            return subHost;
        }

        // Extract host from given URL
        function removeURIPath(fromUrl) {
            //TODO: validate the domain name must be comcast.com else throw error
            var rootContext = fromUrl.replace(/(https?:\/\/[^\/]*)\/.*$/i, "$1");
            console.log("url : " + fromUrl + " - removeURIPath " + rootContext);
            return rootContext;
        }


    }]);
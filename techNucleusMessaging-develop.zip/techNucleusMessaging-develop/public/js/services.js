/* Generic Services */                                                                                                                                                                                                    

var messagingServices = angular.module('messagingServices', []);


messagingServices.factory("httpProxy", ['$http',function($http) {

	var httpProxyInstance = function(requestConfig) {
		if (!angular.isObject(requestConfig)) {
	        throw minErr('httpProxy')('badreq', 'Http request configuration must be an object.  Received: {0}', requestConfig);
	      }

	      if (!angular.isString(requestConfig.url)) {
	        throw minErr('httpProxy')('badreq', 'Http request configuration url must be a string.  Received: {0}', requestConfig.url);
	      }
	      
	      console.log("url requested : " + requestConfig.url);
	      
	      //validate the domain name must be comcast.com else throw error
	      var subHost = requestConfig.url.replace(/https?:\/\/([^\/]*).comcast.com.*/i, "$1");
	      var path = requestConfig.url.replace(/https?:\/\/[^\/]*.comcast.com(.*)/i, "$1");
	      console.log("subHost " + subHost + " -- path " + path);
	      if(path == ''){
	    	  path = '/';
	      }
	      // /ls2/?_subHost=lyncdiscover.cable
	      var theURL = 'ls2' + path + ((path.indexOf('?') > -1) ? '&' : '?') + '_subHost=' + subHost;
	      console.log("final URL " + theURL);

	      //now transform request and convert to proxy URL
	      requestConfig.url = theURL;
			
	      //call the actual http service
	      return $http(requestConfig);
	}
	
//	httpProxyInstance.prototype = 
//		{	get: function(url, config) {
//			  return httpProxyInstance(angular.extend({}, config || {}, {
//				  method: 'get',
//				  url: url
//			  }));
//			}
//		};
	
	createShortMethods('get', 'delete', 'head', 'jsonp');
	
	createShortMethodsWithData('post', 'put', 'patch');
	
	function createShortMethods(names) {
		angular.forEach(arguments, function(name) {
	    	httpProxyInstance[name] = function(url, config) {
	    		  return httpProxyInstance(angular.extend({}, config || {}, {
	    			  method: name,
	    			  url: url
	    		  }));
	    	  };
	      	}
	      );
	    }
	
	function createShortMethodsWithData(name) {
		angular.forEach(arguments, function(name) {
			httpProxyInstance[name] = function(url, data, config) {
	          return $http(angular.extend({}, config || {}, {
	            method: name,
	            url: url,
	            data: data
	          }));
	        };
		});
	}
	
	return httpProxyInstance;
}]);


messagingServices.factory("proxyURLBuilder", [function() {

	var proxyURLBuilderInstance = function(url2Proxy) {
		
	      console.log("url requested : " + url2Proxy);
	      
	      //validate the domain name must be comcast.com else throw error
	      var subHost = url2Proxy.replace(/https?:\/\/(.*).comcast.com/i, "$1");
	      console.log("subHost " + subHost);
	      
	      var path = url2Proxy.replace(/https?:\/\/.*.comcast.com(.*)/i, "$1");
	      if(path == ''){
	    	  path = '/';
	      }
	      // /ls2/?_subHost=lyncdiscover.cable
	      var theURL = 'ls2' + path + ((path.indexOf('?') > -1) ? '&' : '?') + '_subHost=' + subHost;
	      console.log("final URL " + theURL);

	      //now transform request and convert to proxy URL
	      return theURL;
	}
		
	return proxyURLBuilderInstance;
}]);



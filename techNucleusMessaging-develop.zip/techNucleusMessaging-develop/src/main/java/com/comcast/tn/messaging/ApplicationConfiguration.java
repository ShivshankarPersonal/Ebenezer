package com.comcast.tn.messaging;

import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.filter.HttpPutFormContentFilter;
import org.springframework.web.filter.RequestContextFilter;

import com.comcast.tn.messaging.web.URITemplateProxyServlet;

/**
 * Configuration for Lync Proxy...
 * 
 * @author mkansa001c
 *
 */
@Configuration
public class ApplicationConfiguration {

	@Bean
	public ServletRegistrationBean servletRegistrationBean() {
//		ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new LyncProxyServlet(),
//				"/ls2/*");
		ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(new URITemplateProxyServlet(),
				"/ls2/*");
		servletRegistrationBean.addInitParameter("targetUri", "https://{_subHost}.comcast.com/");
		servletRegistrationBean.addInitParameter(URITemplateProxyServlet.P_LOG, "true");
		return servletRegistrationBean;
	}
	
	@Bean
	public FilterRegistrationBean registration1(CharacterEncodingFilter filter) {
	    FilterRegistrationBean registration = new FilterRegistrationBean(filter);
	    registration.setEnabled(false);
	    return registration;
	}
	
	@Bean
	public FilterRegistrationBean registration2(HiddenHttpMethodFilter filter) {
	    FilterRegistrationBean registration = new FilterRegistrationBean(filter);
	    registration.setEnabled(false);
	    return registration;
	}
	
	@Bean
	public FilterRegistrationBean registration3(HttpPutFormContentFilter filter) {
	    FilterRegistrationBean registration = new FilterRegistrationBean(filter);
	    registration.setEnabled(false);
	    return registration;
	}
	
	@Bean
	public FilterRegistrationBean registration4(RequestContextFilter filter) {
	    FilterRegistrationBean registration = new FilterRegistrationBean(filter);
	    registration.setEnabled(false);
	    return registration;
	}
	
}
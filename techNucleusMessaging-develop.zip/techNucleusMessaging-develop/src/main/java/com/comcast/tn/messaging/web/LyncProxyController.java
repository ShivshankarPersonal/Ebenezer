package com.comcast.tn.messaging.web;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class LyncProxyController {
	Logger log = LoggerFactory.getLogger(LyncProxyController.class);
    
    @RequestMapping(path={"/lp/{domain}","/lp/{domain}/*"}, method=RequestMethod.GET)
    public String getProxy(@PathVariable String domain, HttpServletRequest request) {
    	
        return "get Proxy "  + getRequestInfoHtml(request);
    }
    
    @RequestMapping(path={"/lp/{domain}","/lp/{domain}/*"},  method=RequestMethod.POST)
    public String postProxy(@PathVariable String domain, HttpServletRequest request) {
        return "post Proxy  "  + getRequestInfoHtml(request);
    }


    @RequestMapping(path={"/lp/{domain}","/lp/{domain}/*"}, method=RequestMethod.PUT)
    public String putProxy(@PathVariable String domain, HttpServletRequest request) {
        return "put Proxy  "  + getRequestInfoHtml(request);
    }
    
    private String getRequestInfoHtml(HttpServletRequest request){
    	//Get all the headers and pass it to domain along with rest of request
    	StringBuffer rb = new StringBuffer();
    	//rb.append("Will call").append(domain);
    	rb.append("<br/>with request").append(request.getRequestURI());
    	Enumeration<String> he = request.getHeaderNames();
    	rb.append("<br/> Headers : ");
    	if(he.hasMoreElements()){
    		String headerName = he.nextElement();
    		rb.append(headerName).append("=").append(request.getHeader(headerName)).append("<br/>");
    	}
    	rb.append("<br/> Parameters : ");
    	rb.append(request.getParameterMap());
    	return rb.toString();
    }
    
}

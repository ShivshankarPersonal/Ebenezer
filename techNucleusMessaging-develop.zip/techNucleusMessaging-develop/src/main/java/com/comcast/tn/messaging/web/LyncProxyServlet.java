package com.comcast.tn.messaging.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.comcast.tn.messaging.Application;

public class LyncProxyServlet extends URITemplateProxyServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(Application.class);

	protected void copyRequestHeaders(HttpServletRequest servletRequest, HttpRequest proxyRequest) {
		super.copyRequestHeaders(servletRequest, proxyRequest);
		log.debug("Headers are copied now replacing referer header...");
		String referer = servletRequest.getHeader("x-referer");
		if(referer == null){
			log.debug("No referer replacement");
		}
		else{
			proxyRequest.removeHeaders("referer"); //if not removed shows up twice..
			log.debug("referer = {}", referer);
			proxyRequest.addHeader("Referer", referer);
			proxyRequest.removeHeaders("x-referer");
		}
//
//		String queryString = "?" + servletRequest.getQueryString();
//		int hash = queryString.indexOf('#');
//		if (hash >= 0) {
//			queryString = queryString.substring(0, hash);
//		}
//		List<NameValuePair> pairs;
//		try {
//			// note: HttpClient 4.2 lets you parse the string without building
//			// the URI
//			pairs = URLEncodedUtils.parse(new URI(queryString), "UTF-8");
//			for (NameValuePair pair : pairs) {
//				if("referer".equals(pair.getName())){
//					//Found referer header
//					log.debug("Got referer replacement : " + pair.getValue());
//					proxyRequest.addHeader("referer", pair.getValue());
//				}
//			}
//		} catch (URISyntaxException e) {
//			// should never reach here as if that happens it would have happend
//			// before itself...
//			log.warn("LyncProxyServlet got Unexpected URI parsing error on " + queryString
//					+ "  - skillping referer header change", e);
//		}
	}
}

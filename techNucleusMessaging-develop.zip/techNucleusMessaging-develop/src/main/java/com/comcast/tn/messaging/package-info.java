/**
 * This package should be renamed to the service
 * provided by this micro-service 
 * 
 * Ref : http://docs.spring.io/spring-boot/docs/1.3.1.RELEASE/reference/htmlsingle/#using-boot-locating-the-main-class
 * 
 */
package com.comcast.tn.messaging;
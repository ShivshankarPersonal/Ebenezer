/**
 * All Domain Object Goes here... 
 */
package com.comcast.tn.messaging.domain;
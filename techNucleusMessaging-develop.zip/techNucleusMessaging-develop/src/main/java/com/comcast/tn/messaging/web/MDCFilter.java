package com.comcast.tn.messaging.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.comcast.tn.logger.mdc.MDCUtil;
import com.comcast.tn.logger.mdc.MDCUtil.RequestSource;

/**
 * Filter is responsible for adding and removing MDC
 * ID which uniquely identifies all the log lines based 
 * on request passed from filter.
 * 
 * @author mkansa001c
 *
 */
@WebFilter("/*")
public class MDCFilter implements Filter {

	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try{
			addRequestIdMDC(request);
			chain.doFilter(request, response);
		}
		finally{
			MDCUtil.clearRequestIdMDC();
		}
	}

	/**
	 * Add Request ID with or with caller reference 
	 * based on request introspection 
	 * 
	 * @param request
	 */
	private void addRequestIdMDC(ServletRequest request) {
		String callerRef = null;
		if (request instanceof HttpServletRequest){
			HttpServletRequest httpReq = (HttpServletRequest) request;
			callerRef = httpReq.getHeader("x-callref");
		}
		MDCUtil.addRequestIdMDC(RequestSource.HTTP, callerRef);
	}

	public void destroy() {
		
	}

}

package com.comcast.tn.messaging.web;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;


/**
 * Allow management of service status (in the service or not) using JMX
 * 
 * @see http://docs.spring.io/autorepo/docs/spring/4.2.x/spring-framework-reference/html/jmx.html
 * @author mkansa001c
 *
 */

@Component
@ManagedResource(
	objectName="com.comcast.tn:name=Admin",
	description="Controls Admin aspects of the application")
public class AdminMBean {
	
	/**
	 * Number of Consumer invoking service...
	 */
	private AtomicLong consumerCount = new AtomicLong();

	/**
	 * This drives the Service  Heath Check value
	 */
	private boolean outOfService = false;
	
	/**
	 * When was last time {@link #outOfService} value got modified...
	 */
	private long outOfServiceRequestTime = 0;
	
	@ManagedAttribute(description="Out of Service Status - controls if Service Health Check status is out of service not in service")
	public boolean isOutOfService() {
		return outOfService;
	}

	@ManagedAttribute(description="Out of Service Status",
            currencyTimeLimit=20,
            defaultValue="false",
            persistPolicy="OnUpdate")
	public void setOutOfService(boolean outOfService) {
		this.outOfService = outOfService;
		this.outOfServiceRequestTime = System.currentTimeMillis();
	}

	public long getOutOfServiceRequestTime() {
		return outOfServiceRequestTime;
	}
	
	public long increaseConsumerCount(){
		//Give some grace period to determine out of service to HAProxy
		//long now = System.currentTimeMillis();
		if(!outOfService ){
			return consumerCount.incrementAndGet();
		}
		return consumerCount.longValue();
	}
	
	public long decreaseConsumerCount(){
		return consumerCount.decrementAndGet();
	}
	
	@ManagedAttribute(description="How many consumers are being served as of now...")
	public long getConsumerCount(){
		return consumerCount.longValue();
	}
	
	@ManagedOperation(description="Take Service offline, allow requests to complete and perform exit Java Process")
	public void performGracefulShutdown(){
		setOutOfService(true);
		//TODO : Wait for all services to finish
//		new Thread(new Runnable() {
//			@Override
//			public void run() {
//				try {
//					Thread.sleep(500L);
//				}
//				catch (InterruptedException ex) {
//					// Swallow exception and continue
//				}
//				ShutdownEndpoint.this.context.close();
//			}
//		}).start();

	}


}

//package com.comcast.tn.messaging.web;
//
//import java.util.Date;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.actuate.health.Health;
//import org.springframework.boot.actuate.health.HealthIndicator;
//import org.springframework.stereotype.Component;
//
//@Component
//public class ServiceHealthCheck implements HealthIndicator {
//	
//	@Autowired
//	AdminMBean oosStatus;
//
//	public Health health() {
//        if (oosStatus.isOutOfService()) {
//        	return Health.outOfService().withDetail("Out Of Service Requested at ", 
//        			new Date(oosStatus.getOutOfServiceRequestTime())).build();
//        }
//        return Health.up().build();
//    }
//}

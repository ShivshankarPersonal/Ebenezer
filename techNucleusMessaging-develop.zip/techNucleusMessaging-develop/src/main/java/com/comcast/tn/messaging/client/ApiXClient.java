package com.comcast.tn.messaging.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ApiXClient {

	@Value("${apiX.url}")
	private String url;
	

	@Value("${apiX.key}")
	private String key;
	
	public void invokeAPI(){
		
	}
	
}

# TechNucleus Messaging Service

#### Purpose  
Provide messaging infrastructure. As of current implementation
* Works as proxy for lync server


#### Run the app  
* Needs java & Gradle


>gradle run

And browser URL – http://localhost:8080/

All js & html are inside folder public.

#### Working with the project.

* Collaboration model - http://nvie.com/posts/a-successful-git-branching-model/
* Checkout - https://github.com/nvie/gitflow
* use **develop** as an integration branch for your contributions.
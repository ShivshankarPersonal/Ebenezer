describe('httpProxyService', function() {
	var mock, httpProxy;
	
	beforeEach(module('messagingApp'));
	
	beforeEach(function() {

		mock = jasmine.createSpy();
		
		module(function($provide) {
			$provide.value('$http', mock);
		});

		inject(function($injector) {
			httpProxy = $injector.get('httpProxy');
		});
	});
	
	// Test service availability
	it('check the existence of httpProxy factory', inject(function(httpProxy) {
		expect(httpProxy).toBeDefined();
	}));

	it('Should have get helper methods', inject(function(httpProxy) {
		expect(httpProxy.get).toBeDefined();
		
		//everything good now
		//expect(mock.alert).not.toHaveBeenCalled();
	}));
	
	
	it('for https://lyncdiscover.cable.comcast.com url proxy url ls2/?_subHost=lyncdiscover.cable is generated', 
			inject(function(httpProxy) {
		httpProxy.get('https://lyncdiscover.cable.comcast.com');
		
		//everything good now
		expect(mock).toHaveBeenCalled();
		console.log("mock args " + xinspect(mock.mostRecentCall.args));
		expect(mock.mostRecentCall.args[0]['url']).toEqual('ls2/?_subHost=lyncdiscover.cable');
	}));
	
	it('for https://extlyncpool04.comcast.com/Autodiscover/AutodiscoverService.svc/root/oauth/user?originalDomain=cable.comcast.com ' + 
			' url ls2/Autodiscover/AutodiscoverService.svc/root/oauth/user?originalDomain=cable.comcast.com&_subHost=lyncdiscover.cable is generated', 
			inject(function(httpProxy) {
		httpProxy.get('https://extlyncpool04.comcast.com/Autodiscover/AutodiscoverService.svc/root/oauth/user?originalDomain=cable.comcast.com');
		
		//everything good now
		expect(mock).toHaveBeenCalled();
		console.log("mock args " + xinspect(mock.mostRecentCall.args));
		expect(mock.mostRecentCall.args[0]['url']).toEqual('ls2/Autodiscover/AutodiscoverService.svc/root/oauth/user?originalDomain=cable.comcast.com&_subHost=extlyncpool04');
	}));
	
	
});


function xinspect(o,i){
    if(typeof i=='undefined')i='';
    if(i.length>50)return '[MAX ITERATIONS]';
    var r=[];
    for(var p in o){
        var t=typeof o[p];
        r.push(i+'"'+p+'" ('+t+') => '+(t=='object' ? 'object:'+xinspect(o[p],i+'  ') : o[p]+''));
    }
    return r.join(i+'\n');
}